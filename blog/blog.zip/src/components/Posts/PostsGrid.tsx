import React from 'react';

export default function PostsGrid() {
  return <div>PostsGrid</div>;
}
