import React from 'react';

export default function Footer() {
  return (
    <footer className='bg-slate-900 text-white py-2 text-center'>
      Dont forget to CODE your DREAM | All Right Reserved.
    </footer>
  );
}
