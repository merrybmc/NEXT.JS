import React from 'react';

export default function PostsPage() {
  return <div>posts 페이지</div>;
}
