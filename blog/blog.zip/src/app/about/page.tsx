import React from 'react';

export default function AboutPage() {
  return <div>소개 페이지</div>;
}
