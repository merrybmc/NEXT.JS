import React from 'react';

export default function ContactPage() {
  return <div>contact 페이지</div>;
}
